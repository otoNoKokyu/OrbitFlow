import { Module, Scope } from '@nestjs/common';
import { NotificationService } from './notification.service';
import { MailService } from 'src/utility/mail/mail.service';
import { IssueRepository } from '../issues/issue.repository';
import { RedisService } from 'src/utility/redis/redis.service';
import Redis from 'ioredis';
import { ServiceException } from 'src/helper/CustomError';
import { ERR_TYPE } from 'src/interface/CustomError';
import { RedisPolicy } from 'src/utility/redis/redis.type';

@Module({
  
  providers: [ MailService, NotificationService,IssueRepository,
    {
      provide: 'ISSUE_POLICY',
      useValue: RedisPolicy.ISSUE,
    },
    {
      provide: 'serviceException',  
      useClass: ServiceException,  
    },
    {
      provide: RedisService,
      useFactory: (policy: RedisPolicy, exceptionClass: ServiceException<ERR_TYPE>) => new RedisService(new Redis(), policy, exceptionClass),
      inject: ['ISSUE_POLICY', 'serviceException'],
      scope: Scope.REQUEST,
    },
  ]
})
export class NotificationModule {}
